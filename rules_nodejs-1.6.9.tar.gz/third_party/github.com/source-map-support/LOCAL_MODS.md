- Added code within '//BAZEL LOCAL MOD' to fix the stack for Bazel stacks

